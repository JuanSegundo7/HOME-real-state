import React from "react";

const resendTemplate = () => {
  return <div>resendTemplate</div>;
};

export default resendTemplate;
