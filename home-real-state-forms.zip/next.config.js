/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "export",
  reactStrictMode: true,
  images: {
    domains: ["images.unsplash.com", "localhost", "lh3.googleusercontent.com"],
  },
};

module.exports = nextConfig;
